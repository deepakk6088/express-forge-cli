# Express Forge CLI

Generate a ready-to-use Express.js backend with PostgreSQL and Prisma ORM using a simple CLI.

## Features

- Express.js backend setup
- PostgreSQL database integration
- Prisma ORM 7.10.1
- Environment variable configuration
- CORS configuration
- Health check endpoint
- Error-handling middleware
- Database migrations and seeding

## Requirements

- Node.js
- PostgreSQL

## Usage

Generate a new backend:

```bash
npx express-forge-cli my-backend
```

Follow the prompts to configure your server port, PostgreSQL connection URL, and frontend URL.

## Setup

Move into your generated project:

```bash
cd my-backend
```

Install dependencies:

```bash
npm install
```

Configure your PostgreSQL connection URL in `.env`.

Generate Prisma Client:

```bash
npx prisma generate
```

Run database migrations:

```bash
npx prisma migrate dev --name init
```

Seed the database:

```bash
npm run db:seed
```

Start the development server:

```bash
npm run dev
```

## Available Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start development server |
| `npm start` | Start production server |
| `npm run db:generate` | Generate Prisma Client |
| `npm run db:migrate` | Run database migrations |
| `npm run db:deploy` | Deploy migrations |
| `npm run db:seed` | Seed the database |

## Default API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/api` | API status |

## License

MIT